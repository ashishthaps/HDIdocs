﻿using System;
using System.Configuration;
using Microsoft.Hadoop.WebHDFS.Adapters;
using Microsoft.Hadoop.WebHDFS;

namespace LoadSensorData
{
    class Program
    {
        static void Main(string[] args)
        {


            // Get Azure storage settings from App.Config.
            var hdInsightUser = ConfigurationManager.AppSettings["HDInsightUser"];
            var storageKey = ConfigurationManager.AppSettings["StorageKey"];
            var storageName = ConfigurationManager.AppSettings["StorageName"];
            var containerName = ConfigurationManager.AppSettings["ContainerName"];
            var destFolder = ConfigurationManager.AppSettings["InputDir"];

            // Upload GPS data.
            var hdfsClient = new WebHDFSClient(
                hdInsightUser,
                new BlobStorageAdapter(storageName, storageKey, containerName, false));

            var sensorFile = "sensor.csv";

            hdfsClient.CreateFile(AppDomain.CurrentDomain.BaseDirectory.Replace("\\bin\\Debug", "") + "\\" + sensorFile, destFolder + "/sensor.csv").Wait();

            Console.WriteLine("Uploading sensor data...");
            Console.ReadKey();

        }
    }
}
